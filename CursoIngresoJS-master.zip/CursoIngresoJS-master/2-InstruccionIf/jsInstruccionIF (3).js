function mostrar() {
    //tomo la edad  
    var edad = document.getElementById("edad").value;
    edad = parseInt(edad);
    if (edad >= 18) {
        alert("Mayor de edad");
    }
    else {
        alert("Menor de edad");
    }

}//FIN DE LA FUNCIÓN