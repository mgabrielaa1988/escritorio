function mostrar() {
    //tomo la edad  
    var edad = document.getElementById("edad").value;
    edad = parseInt(edad);
    if (edad == 15) {
        alert("niña bonita");
    }

}//FIN DE LA FUNCIÓN