function mostrar() {
	var contador = 10;

	while (contador > 0) {
		alert(contador);
		contador--;
	}

}//FIN DE LA FUNCIÓN