﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Excepciones;

namespace ClasesAbstractas
{
    public abstract class Persona
    {
        #region Enumerado
        public enum ENacionalidad
        {
            Argentino,
            Extranjero
        }
        #endregion

        #region Atributos
        private string _apellido;
        private int _dni;
        private ENacionalidad _nacionalidad;
        private string _nombre;
        #endregion

        #region Propiedades
        public string Apellido
        {
            get
            {
                return this._apellido;
            }
            set
            {
                this._apellido = ValidarNombreApellido(value);
            }
        }
        public string Nombre
        {
            get
            {
                return this._nombre;
            }
            set
            {
                this._nombre = ValidarNombreApellido(value);
            }
        }
        public int DNI
        {
            get
            {
                return this._dni;
            }
            set
            {
                this._dni = ValidarDni(this._nacionalidad, value);
            }
        }
        public ENacionalidad Nacionalidad
        {
            get
            {
                return this._nacionalidad;
            }
            set
            {
                if (value == ENacionalidad.Argentino || value == ENacionalidad.Extranjero)
                {
                    this._nacionalidad = value;
                }
            }
        }       
        public string StringToDNI
        {
            set
            {
                this._dni = ValidarDni(this._nacionalidad,value);
            }
        }
        #endregion

        #region Contructores
        public Persona():this("","",ENacionalidad.Argentino)
        { }
        public Persona(string nombre,string apellido,ENacionalidad nacionalidad)
        {
            this._nombre = nombre;
            this._apellido = apellido;
            this._nacionalidad = nacionalidad;
        }
        public Persona(string nombre, string apellido,int dni, ENacionalidad nacionalidad)
            :this(nombre,apellido,nacionalidad)
        {
            this._dni = dni;
        }
        public Persona(string nombre, string apellido,string dni, ENacionalidad nacionalidad)
            :this(nombre,apellido,nacionalidad)
        {
            this.StringToDNI = dni;
        }
        #endregion

        #region Metodos
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("NOMBRE COMPLETO: {0}, {1}\n", this.Apellido, this.Nombre);
            sb.AppendFormat("NACIONALIDAD: {0}\n", this.Nacionalidad.ToString());
            return sb.ToString();
        }
        private int ValidarDni(ENacionalidad nacionalidad,int dato)
        {
            if ((nacionalidad == ENacionalidad.Argentino && (dato <= 89999999 && dato >= 1)) ||
                (nacionalidad == ENacionalidad.Extranjero && (dato <= 99999999 && dato >= 90000000)))
            {
                return dato;
            }
            else
            {
                if (dato > 99999999 || dato < 1)
                {
                    throw new DniInvalidoException();
                }
                else
                {
                    throw new NacionalidadInvalidaException();
                }
            }
        }
        private int ValidarDni(ENacionalidad nacionalidad, string dato)
        {
            int retorno = 0;
            if ((dato.Length < 9) && (dato.Length > 0)&& (int.TryParse(dato, out int dni)))
            {
                retorno = ValidarDni(nacionalidad, dni);
            }
            else
            {
                throw new DniInvalidoException();
            }
            return retorno;
        }
        private string ValidarNombreApellido(string dato)
        {
            string retorno = "";
            if (Regex.IsMatch(dato, (@"^[a-zA-Z]+$")))
            {
                retorno = dato;
            }
            return retorno;
        }
        #endregion
    }
}
