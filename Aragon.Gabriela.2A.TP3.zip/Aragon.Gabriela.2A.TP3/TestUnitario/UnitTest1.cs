﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Archivos;
using ClasesAbstractas;
using ClasesInstanciables;
using Excepciones;

namespace TestUnitario
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestAlumnoRepetidoException()
        {
            Universidad u = new Universidad();
            Alumno alumno1 = new Alumno(1, "Juan", "Perez", "12345678", Persona.ENacionalidad.Argentino, Universidad.EClases.Laboratorio);
            Alumno alumno2 = new Alumno(1, "Juan", "Perez", "12345678", Persona.ENacionalidad.Argentino, Universidad.EClases.Laboratorio);
            u.Alumnos.Add(alumno1);
            try
            {
                u.Alumnos.Add(alumno2);
            }
            catch (Exception e)
            {
                Assert.IsInstanceOfType(e, typeof(AlumnoRepetidoException));
            }
        }

        [TestMethod]
        public void TestMDniInvalidoException()
        {
            try
            {
                Alumno alumno = new Alumno(1, "Juan", "Perez", "90000000m", Persona.ENacionalidad.Argentino, Universidad.EClases.Laboratorio);
            }
            catch (Exception e)
            {
                Assert.IsInstanceOfType(e, typeof(DniInvalidoException));
            }
        }

        [TestMethod]
        public void TestNacionalidadInvalidaException()
        {
            try
            {
                Alumno alumno = new Alumno(1, "Juan", "Perez", "90000000", Persona.ENacionalidad.Argentino, Universidad.EClases.Laboratorio);
            }
            catch (Exception e)
            {
                Assert.IsInstanceOfType(e, typeof(NacionalidadInvalidaException));
            }
        }

        [TestMethod]
        public void TestValidarNull()
        {
            Universidad u = new Universidad();
            foreach (Alumno alumno in u.Alumnos)
            {
                Assert.IsNotNull(alumno.Apellido);
                Assert.IsNotNull(alumno.Nombre);
                Assert.IsNotNull(alumno.Nacionalidad);
                Assert.IsNotNull(alumno.DNI);
            }
        }
    }
}
