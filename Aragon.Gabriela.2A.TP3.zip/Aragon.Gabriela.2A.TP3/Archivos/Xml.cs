﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
using System.IO;

namespace Archivos
{
    public class Xml<T> : IArchivo<T>
    {
        public bool Guardar(string archivo, T datos)
        {
            bool retorno = false;
            if (archivo != null && datos != null)
            {
                XmlTextWriter file = new XmlTextWriter(archivo, Encoding.UTF8);
                XmlSerializer xml = new XmlSerializer(datos.GetType());
                xml.Serialize(file, datos);
                file.Close();
                retorno = true;
            }
            return retorno;
        }

        public bool Leer(string archivo, out T datos)
        {
            XmlTextReader file = new XmlTextReader(archivo);
            XmlSerializer xml = new XmlSerializer(typeof(T));
            datos = (T)xml.Deserialize(file);
            file.Close();
            return File.Exists(archivo);
        }
    }
}
