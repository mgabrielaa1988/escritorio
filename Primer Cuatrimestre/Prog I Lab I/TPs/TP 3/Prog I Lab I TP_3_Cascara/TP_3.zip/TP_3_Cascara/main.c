#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <conio.h>
#include "TP3 Funciones.h"
#define TAM 15


int main()
{
    EMovie movie[TAM];
    char seguir='s';
    char guardar='s';
    int i;
    cargarArchivo(movie,TAM);
    inicializarPeliculas(movie,TAM);

    do
    {
        switch(menu())
        {
        case '1':
            agregarPelicula(movie);
            break;
        case '2':
            borrarPelicula(movie,TAM);
            break;
        case '3':
            modificarPelicula(movie,TAM);
            break;
        case '4':
            generarPagina(movie,TAM);
            break;
        case '5':
            listar(movie,TAM);
            break;
        case '6':
            printf("\nGuardar cambios S/N ?: ");
            guardar = tolower(getche());

            if(guardar == 's')
            {
                if(guardarEnArchivo(movie,TAM))
                {
                    printf("\nNo se pudo abrir el fichero\n");
                }
                else
                {
                    printf("\nSe guardo la informacion con exito\n");
                }
            }
            seguir = 'n';
            break;
        }
    }
    while (seguir == 's');
    printf("\n");
    return 0;
}
