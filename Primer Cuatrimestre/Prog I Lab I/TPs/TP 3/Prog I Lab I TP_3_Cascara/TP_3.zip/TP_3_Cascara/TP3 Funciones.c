#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<ctype.h>
#include<conio.h>
#include "TP3 Funciones.h"

void inicializarPeliculas(EMovie movie[],int tam)
{
    char titulo[][100]= {"Avatar","Titanic","Star Wars: Episode VII - The Force Awakens","Jurassic World","The Avengers","Furious 7","Avengers: Age of Ultron","Harry Potter y las Reliquias de la Muerte - Parte 2","Frozen","La Bella y la Bestia"};
    char genero[][100]= {"Ciencia ficcion, Aventura, Accion, Fantastico","Romance, Catastrofe, Drama","Space opera, Epico","Ciencia ficcion, Aventuras, Terror, Accion","Accion, Aventuras, Ciencia ficcion, Superheroes","Accion, Aventuras, Crimen, Romance, Suspenso, Drama","Accion, Aventuras, Ciencia ficcion, Superheroes","Accion, Fantasia, Aventuras","Animacion, Comedia, Aventuras, Drama, Musical, Fantasia, Romance","Drama, Fantasia, Musical, Romance"};
    int duracion[]= {162,195,136,124,142,140,142,130,102,129};
    char descripcion[][200]= {"Unos cientificos descubren la aldea de los pitufos y un hombre se somete a una cirugia para irse a vivir con ellos.","Una abuelita le cuenta a su nieta la vez que se acosto con un vagabundo y luego lo mato.","Un emo trata de matar a la joven de la basura todo porque su papa no le pon�a la atenci�n que el quer�a.","El tipo de Guardianes de la Galaxia da de comer a un pescado un costoso dinosaurio.","Un grupo de supermodelos salva la Tierra del ex novio de Taylor Swift.","Un grupo de ladrones y un hombre hecho por computadora tendran que unirse para pelear contra el tipo del transportador.","Los mismos modelos se enfrentan a Ultron.","Un ni�o llega a la pubertad y descubre las cosas que puede haer con su varita.","Una mujer aterroriza a todo un pueblo porque su hermana menor se va a casar antes que ella.","Todos huyen del feo del pueblo pero una chica descubre que es millonario y ese mismo d�a se va a vivir con �l."};
    int puntaje[]= {7, 7, 7, 6, 7, 6, 6, 7, 6, 7, 0, 0, 0, 0, 0};
    char linkImagen[][200]= {"https://andro4all.com/files/2016/06/Avatar-2.jpg","https://images-na.ssl-images-amazon.com/images/M/MV5BMDdmZGU3NDQtY2E5My00ZTliLWIzOTUtMTY4ZGI1YjdiNjk3XkEyXkFqcGdeQXVyNTA4NzY1MzY@._V1_UY1200_CR88,0,630,1200_AL_.jpg","http://newsite.theroyal.to/wp-content/uploads/2016/03/star-wars-the-force-awakens-quad-poster.jpg","http://www.lascosasquenoshacenfelices.com/wp-content/uploads/2016/11/jurassic-world-cosas-felices.jpg","https://georgespigot.files.wordpress.com/2012/10/the-avengers-15.jpg","http://acranger.com/wp-content/uploads/2015/04/FURIOUS7.jpg","https://static.comicvine.com/uploads/original/9/95970/4529342-avengers__age_of_ultron_poster__fm__by_krallbaki-d8gdz0n.jpg","https://pics.filmaffinity.com/harry_potter_and_the_deathly_hallows_part_ii-477385286-large.jpg","https://tendencybook.com/wp-content/uploads/2017/05/Frozen-portada.jpg","https://lumiere-a.akamaihd.net/v1/images/es_batb_flex-hero_header_r_e5a7127d.jpeg?region=0,0,1536,691&width=1200"};
    int i;

    for (i=0; i<tam; i++)
    {
        strcpy(movie[i].titulo,titulo[i]);
        strcpy(movie[i].genero,genero[i]);
        movie[i].duracion = duracion[i];
        strcpy(movie[i].descripcion,descripcion[i]);
        movie[i].puntaje = puntaje[i];
        strcpy(movie[i].linkImagen,linkImagen[i]);
    }
}

char menu()
{
    char c;
    printf("\n  ----------------------\n");
    printf("  ---------MENU---------\n");
    printf("  ----------------------\n");
    printf("  1- Agregar pelicula\n");
    printf("  2- Borrar pelicula\n");
    printf("  3- Modificar pelicula\n");
    printf("  4- Generar pagina web\n");
    printf("  5- Listar\n");
    printf("  6- Salir\n");
    printf("  Elija una opcion: ");
    c = getche();

    while((int)c < 49 || (int)c > 54)
    {
        printf("  Reingrese una opcion valida: ");
        c = getche();
    }
    return c;
}

void agregarPelicula(EMovie movie[])
{
    char titulo[100];
    char genero[100];
    int duracion;
    char descripcion[200];
    int puntaje;
    char linkImagen[200];
    int index;

    index = buscarLibre(movie,15);
    if (index != -1)
    {
        printf("  Ingrese los datos de la nueva pelicula\n");
        printf("  Titulo: \n");
        fflush(stdin);
        gets(titulo);
        printf("  Genero: \n");
        fflush(stdin);
        gets(genero);
        printf("  Duracion: \n");
        scanf("%d",&duracion);
        printf("  Descripcion: \n");
        fflush(stdin);
        gets(descripcion);
        printf("  Puntaje: \n");
        scanf("%d",&puntaje);
        printf("  Link a imagen: \n");
        fflush(stdin);
        gets(linkImagen);
    }

    if(newMovie(movie,titulo,genero,duracion,descripcion,puntaje,linkImagen))
    {
        printf("  Pelicula agregada!");
    }
    else
    {
        printf("  ERROR... carga de datos fallida");
    }
}

int buscarLibre (EMovie movie[],int tam)
{
    int index = -1;
    int i;

    for (i=0; i<tam; i++)
    {
        if (movie[i].puntaje == 0)
        {
            index = i;
            break;
        }
    }
    return index;
}

int newMovie(EMovie* nMovie,char titulo[],char genero[],int duracion,char descripcion[],int puntaje,char link[])
{
    int retorno = 0;

    if(nMovie!=NULL)
    {
        strcpy(nMovie->titulo,titulo);
        strcpy(nMovie->genero,genero);
        nMovie->duracion = duracion;
        strcpy(nMovie->descripcion,descripcion);
        nMovie->puntaje = puntaje;
        strcpy(nMovie->linkImagen,link);
        retorno = 1;
    }
    return retorno;
}

void toString(EMovie* movie)
{
    printf("%s\t\t%s\t\t%d\t\t%s\t\t%d\t\t%s\n",movie->titulo,movie->genero,movie->duracion,movie->descripcion,movie->puntaje,movie->linkImagen);
}

void borrarPelicula(EMovie* movie,int tam)
{
    char auxTitulo[100];
    char opcion;
    int i;
    int flag =0;
    printf("  Ingrese el titulo de la pelicula que desea eliminar: \n");
    fflush(stdin);
    gets(auxTitulo);

    for (i=0; i<tam; i++)
    {
        if(strcmp(movie->titulo,auxTitulo)==0)
        {
            printf("  Pelicula a eliminar: \n");
            toString((movie + i));
            printf("  Confirma eliminar pelicula (s para si): \n");
            opcion = getche();

            if (opcion == 's')
            {
                movie[i].puntaje = 0;
                printf("  Pelicula borrada!\n");
            }
            else
            {
                printf("  La pelicula no fue eliminada\n");
            }
            flag = 1;
            break;
        }
    }
    if (flag == 0)
    {
        printf("  Pelicula inexistente");
    }
}

void modificarPelicula(EMovie* movie, int tam)
{
    char auxTitulo[100];
    char opcion;
    int i;
    int flag = 0;
    char auxGenero[100];
    int auxDuracion;
    char auxDescripcion[200];
    int auxPuntaje;
    char auxLink[100];

    printf("  Ingrese el titulo de la pelicula que desea modificar: \n");
    fflush(stdin);
    gets(auxTitulo);

    for (i=0; i<tam; i++)
    {
        if(strcmp(movie->titulo,auxTitulo)==0)
        {
            printf("  Pelicula encontrada:\n");
            toString((movie + i));

            printf("  Desea modificar el genero? (s=si)");
            opcion = getche();
            if (opcion == 's')
            {
                printf("  Ingrese nuevo genero: \n");
                fflush(stdin);
                gets(auxGenero);
                strcpy(movie[i].genero,auxGenero);
            }
            else
            {
                printf("  El genero no fue modificado");
            }

            printf("  Desea modificar la duracion? (s=si)");
            opcion = getche();
            if (opcion == 's')
            {
                printf("  Ingrese nueva duracion:\n");
                scanf("%d",auxDuracion);
                movie[i].duracion=auxDuracion;
            }
            else
            {
                printf("  La duracion no fue modificada");
            }

            printf("  Desea modificar la descripcion? (s=si)");
            opcion = getche();
            if (opcion == 's')
            {
                printf("  Ingrese nueva descripcion:\n");
                fflush(stdin);
                gets(auxDescripcion);
                strcpy(movie[i].descripcion,auxDescripcion);
            }
            else
            {
                printf("  La descripcion no fue modificada");
            }

            printf("  Desea modificar el puntaje? (s=si)");
            if (opcion == 's')
            {
                printf("  Ingrese nuevo puntaje:\n");
                scanf("%d",auxPuntaje);
                movie[i].puntaje = auxPuntaje;
            }
            else
            {
                printf("  La duracion no fue modificada");
            }

            printf("  Desea modificar el link a la imagen? (s=si)");
            opcion = getche();
            if (opcion == 's')
            {
                printf("  Ingrese nuevo link:\n");
                fflush(stdin);
                gets(auxLink);
                strcpy(movie[i].linkImagen,auxLink);
            }
            else
            {
                printf("  El link no fue modificado");
            }
            flag = 1;
            break;
        }
    }
    if (flag == 0)
    {
        printf("  Pelicula inexistente");
    }
}

void generarPagina(EMovie* movie, int tam)
{
    int i;
    FILE* pFile;
    pFile=fopen("index.html","w");
    if(pFile==NULL)
    {
        printf("\nError al abrir el archivo\n");
        exit(1);
    }
    for(i=0;i<tam;i++)
    {
        if(movie[i].puntaje!=0)
        {
            fprintf(pFile,"<article class='col-md-4 article-intro'> <a href='#'><img class='img-responsive img-rounded' src='%s' alt=''>",movie[i].linkImagen);
            fprintf(pFile,"</a><h3><a href='#'> %s</a></h3><ul>",movie[i].titulo);
            fprintf(pFile,"<li>Genero: %s</li><li>Duracion: %d minutos.</li><li>Descripcion: %s</li><li>Puntaje: %d</li></ul>",movie[i].genero,movie[i].duracion,movie[i].descripcion,movie[i].puntaje);
        }
    }
    fclose(pFile);
    printf("\nPagina creada!");
}

int guardarEnArchivo(EMovie* cambios,int tam)
{
	FILE* archivo;

		archivo=fopen("bin.dat","wb");
		if(archivo == NULL)
		{
		    printf("  Error al abrir el archivo");
			return 1;
		}

	fwrite(cambios,sizeof(EMovie),tam,archivo);
    printf("  Archivo guardado");
	fclose(archivo);

	return 0;
}

  int cargarArchivo(EMovie* movie,int tam)
  {
      int retorno=-1;
      FILE* archivo;
      archivo=fopen("bin.dat","rb");
      if(archivo==NULL)
      {
          archivo=fopen("bin.dat","wb");
          if(archivo==NULL)
          {
              printf("Error al abrir el archivo");
              system("pause");
              return retorno;
          }
      }
      fread(movie,sizeof(EMovie),tam,archivo);
      retorno=0;
      fclose(archivo);
      return retorno;
  }

  void listar(EMovie* movie,int tam)
  {
      int i;

      if(movie!=NULL && tam>0)
      {
          for(i=0;i<tam;i++)
          {
              if(movie[i].puntaje!=0)
              {
                  printf("\n\tTitulo: %s\n\tGenero: %s\n\tDuracion: %d\n\tPuntaje: %d\n\tDescripcion: %s\n\tLink de Imagen: %s\n",movie[i].titulo,movie[i].genero,movie[i].duracion,movie[i].puntaje,movie[i].descripcion,movie[i].linkImagen);
              }
          }
      }
  }
