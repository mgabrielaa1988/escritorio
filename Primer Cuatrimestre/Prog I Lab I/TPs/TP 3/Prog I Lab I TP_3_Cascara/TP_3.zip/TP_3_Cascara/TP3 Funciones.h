#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

typedef struct{
    char titulo[100];
    char genero[100];
    int duracion;
    char descripcion[200];
    int puntaje;
    char linkImagen[200];
} EMovie;

void toString(EMovie*);

int buscarLibre (EMovie*,int tam);

char menu(void);

void inicializarPeliculas(EMovie movie[],int tam);

void agregarPelicula(EMovie*);

int newMovie(EMovie*,char[],char[],int,char[],int,char[]);

void borrarPelicula(EMovie*,int);

void modificarPelicula(EMovie*,int);

int cargarArchivo(EMovie*,int);

void generarPagina(EMovie*,int);

int guardarEnArchivo(EMovie*,int);

void listar(EMovie*,int);

#endif // FUNCIONES_H_INCLUDED

