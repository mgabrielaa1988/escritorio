#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include "funciones.h"
#include "validaciones.h"
#define MAX 20

void inicializar(ePersona persona[],int tam,int valor)
{
    int i;
    for(i=0; i<tam; i++)
    {
        persona[i].estado = valor;
        persona[i].dni = valor;
    }
}

int buscar(ePersona persona[],int tam,int valor)
{
    int i;

    for(i=0; i<tam; i++)
    {
        if(persona[i].estado == valor)
        {
            return i;
        }
    }
    return -1;
}

int buscarPorDni(ePersona persona[],int tam,int valor)
{
    int i;

    for(i=0; i<tam; i++)
    {
        if(persona[i].dni == valor)
        {
            return i;
        }
    }
    return -1;
}

void imprimirGrafico(ePersona valor[],int tam)
{
    int i;
    int j;
    int joven=18;
    int adulto=35;
    int contNino=0;
    int contJoven=0;
    int contAdulto=0;

    putchar('\n');

    for (i=0; i<tam; i++)
    {
        if (valor[i].edad > adulto)
        {
            contAdulto ++;
        }
        else
        {
            if (valor[i].edad < joven)
            {
                contNino ++;
            }
            else
            {
                contJoven ++;

            }
        }
    }

    int valoresPorEdad []= {contNino,contJoven,contAdulto};
    int max =0;

    for (i=0; i<3; i++)
    {
        if (valoresPorEdad[i]>max)
        {
            max = valoresPorEdad[i];
        }
    }
    for(i=max; i>0; i--)
    {
        for (j=0; j<3; j++)
        {
            if (valoresPorEdad[j]>=i)
            {
                printf("      *      ");
            }
            else
            {
                printf("             ");
            }
        }
        putchar('\n');
    }
    printf("\n     <18         19-35         35<");
}

