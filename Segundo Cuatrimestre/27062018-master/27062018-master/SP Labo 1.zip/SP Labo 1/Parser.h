#ifndef PARSER_H_INCLUDED
#define PARSER_H_INCLUDED

#include "ArrayList.h"

int parser_parseEmpleados(char* fileName, ArrayList* listaEmpleados);


#endif // PARSER_H_INCLUDED
