#include "ArrayList.h"

int parser_parseEmpleados(char* fileName, ArrayList* listaEmpleados)
{

    return 1; // OK
}

