#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE* f;
    int n1,n2,n3,n4;
    int cant;

    f = fopen("datos.txt","r");

    if(f == NULL){
        printf("\nNo se pudo abrir el archivo\n");
        exit(EXIT_FAILURE);
    }

    while(!feof(f)){//mientras no llegue al final del archivo
        cant = fscanf(f," %d, %d, %d, %d\n",&n1,&n2,&n3,&n4);//cuento la cantidad de variables, leo los numeros hasta el salto de linea
        if(cant != 4){//si la cantidad leida es diferente a la cantidad de variables
                if(feof(f)){//si llego al final del archivo
                    break;//salgo
                }
                else{
                    printf("\nNo se pudo leer el contenido del archivo\n");
                    exit(EXIT_FAILURE);
                }
        }
        printf(" %d, %d, %d, %d\n",n1,n2,n3,n4);
    }
    fclose(f);

    return 0;
}
