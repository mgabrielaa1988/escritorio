#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct{
    int legajo;
    char nombre[20];
    float sueldo;
    int estado;
}eEmpleado;

eEmpleado* new_Empleado();
eEmpleado* new_EmpleadoParam(int,char*,float);
void mostrar_Empleado(eEmpleado*);
void mostrar_Empleados(eEmpleado*,int);
void inicializar_Empleados(eEmpleado*,int);
eEmpleado* new_ArrayEmpleados(int);
void guardarEmpleados(eEmpleado*,char*)

int main()
{


    return 0;
}

eEmpleado* new_Empleado(){
    eEmpleado* nuevo;
    nuevo = (eEmpleado*)malloc(sizeof(eEmpleado));
    if(nuevo != NULL){
        nuevo->estado=0;
        strcpy(nuevo->nombre,"");
        nuevo->sueldo=0;
        nuevo->estado=0;
    }
    return nuevo;
}

eEmpleado* new_EmpleadoParam(int legajo,char* nombre,float sueldo){
    eEmpleado* aux;
    aux = new_Empleado();
    if(aux != NULL){
        aux->legajo = legajo;
        strcpy(aux->nombre,nombre);
        aux->sueldo = sueldo;
        aux->estado = 1;
    }
    return aux;
}

void mostrar_Empleado(eEmpleado* emp){
    if(emp != NULL)
    printf("%d\t%s\t%.2f\n",emp->legajo,emp->nombre,emp->sueldo);
}

void mostrar_Empleados(eEmpleado* empleados,int tam){
    int i;
    if(empleados != NULL && tam>0){
        for(i=0;i<tam;i++){
            if((empleados + i)-> estado){
                mostrar_Empleado(empleados + i);
            }
        }
    }
    else{
        printf("No se pueden mostrar los empleados");
    }
}

void inicializar_Empleados(eEmpleado* empleados,int tam){
    int i;
    if(empleados != NULL && tam>0){
        for(i=0;i<tam;i++){
            (empleados + i)->estado = 0;
        }
    }
}

eEmpleado* new_ArrayEmpleados(int tam){
    eEmpleado* array;
    if(tam > 0){
        array = (eEmpleado*) malloc(tam * sizeof(eEmpleado));
        if(array != NULL){
            inicializar_Empleados(array,tam);
        }
    }
    return array;
}
