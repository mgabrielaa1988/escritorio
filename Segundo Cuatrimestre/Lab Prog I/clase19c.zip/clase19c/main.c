#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define TAM 20

typedef struct
{
    int id;
    char marca[20];
    char modelo[20];
    char color[15];
    int anio;
    int estado;
} eAuto;

void inicializarEstado(eAuto*,int);
eAuto* buscarLibre(eAuto*,int);
eAuto* new_AutosParam(int,char*,char*,char*,int);
void mostrarAuto(eAuto*);
void mostrarAutos(eAuto*,int);
eAuto* agrandarArray(eAuto*,int*);

int main()
{
    eAuto autos[TAM];
    int id,anio,cant;
    char idCad[10],marca[20],modelo[20],color[15],anioCad[10];
    FILE* f;

    inicializarEstado(autos,TAM);

    f = fopen("autos.csv","r");
    if(f == NULL)
    {
        printf("\nNo se pudo abrir el archivo\n");
        exit(EXIT_FAILURE);
    }

    while(!feof(f))
    {
        cant = fscanf(f,"%[^,],%[^,],%[^,],%[^,],%[^\n]\n",idCad,marca,modelo,color,anioCad);
        if(cant!=5)
        {
            if(feof(f))
            {
                break;
            }
            else
            {
                printf("\nNo se pudo leer el contenido del archivo\n");
                exit(EXIT_FAILURE);
            }
        }
        id = atoi(idCad);
        anio = atoi(anioCad);

        printf(" %4d %15s %17s %15s %4d\n",id,marca,modelo,color,anio);
    }
    fclose(f);
    return 0;
}

void inicializarEstado(eAuto* autom,int tam)
{
    int i;
    if(autom != NULL && tam>0)
    {
        for(i=0; i<tam; i++)
        {
            (autom+i)->estado = 0;
        }
    }
}

eAuto* new_AutosParam(int id,char* marca,char* modelo,char* color,int anio){
    eAuto* nuevo;
    if(nuevo != NULL){
        nuevo->id = id;
        strcpy(nuevo->marca,marca);
        strcpy(nuevo->modelo,modelo);
        strcpy(nuevo->color,color);
        nuevo->anio = anio;
        nuevo->estado = 1;
    }
    return nuevo;
}

void mostrarAuto(eAuto* autom){
    if(autom != NULL){
        printf(" %4d %15s %17s %15s %4d\n",autom->id,autom->marca,autom->modelo,autom->color,autom->anio);
    }
}

void mostrarAutos(eAuto* autos,int tam){
    int i;
    if(autos != NULL && tam>0){
        for(i=0;i<tam;i++){
            if((autos+i)->estado == 1){
                mostrarAuto(autos+i);
            }
        }
    }
}

eAuto* buscarLibre(eAuto* autos,int tam){
    int i;
    eAuto* retorno = NULL;
    if(autos != NULL && tam>0){
        for(i=0;i<tam;i++){
            if((autos+i)->estado == 0)
                retorno = (autos+i);
        }
    }
    return retorno;
}

eAuto* agrandarArray(eAuto* array,int* tam){
    array = (eAuto*) realloc(array,tam * sizeof(eAuto));
    if(array !=NULL){
        inicializarEstado(array,tam);
    }
    return array;
}
