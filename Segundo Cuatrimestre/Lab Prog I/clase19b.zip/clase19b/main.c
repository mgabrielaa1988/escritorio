#include <stdio.h>
#include <stdlib.h>

int main()
{
    int id,anio,cant;
    char idCad[10],marca[20],modelo[20],color[15],anioCad[10];
    FILE* f;
    f = fopen("autos.csv","r");
    if(f == NULL){
        printf("\nNo se pudo abrir el archivo\n");
        exit(EXIT_FAILURE);
    }

    while(!feof(f)){
        cant = fscanf(f,"%[^,],%[^,],%[^,],%[^,],%[^\n]\n",idCad,marca,modelo,color,anioCad);
        if(cant!=5){
            if(feof(f)){
                break;
            }
            else{
                printf("\nNo se pudo leer el contenido del archivo\n");
                    exit(EXIT_FAILURE);
            }
        }
        id = atoi(idCad);
        anio = atoi(anioCad);
        printf(" %4d %15s %17s %15s %4d\n",id,marca,modelo,color,anio);
    }
    fclose(f);
    return 0;
}
