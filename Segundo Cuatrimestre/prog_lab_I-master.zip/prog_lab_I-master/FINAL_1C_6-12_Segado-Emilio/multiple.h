#ifndef MULTIPLE_H_INCLUDED
#define MULTIPLE_H_INCLUDED

sRegistro* obtenerDatosRegistro(ArrayList* registrosList, ArrayList* empleadosList);

int registrarDia(ArrayList* registrosList, ArrayList* empleadosList);

#endif // MULTIPLE_H_INCLUDED
