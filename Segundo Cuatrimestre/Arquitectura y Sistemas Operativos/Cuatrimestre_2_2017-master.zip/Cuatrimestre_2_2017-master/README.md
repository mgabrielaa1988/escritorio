# Cuatrimestre_2_2017
Repositorio creado para la materia Arquitectura y Sistemas Operativos dictada el segundo cuatrimestre el 2017.

  * Cuestionario teórico del primer parcial: https://goo.gl/forms/5SWqbBGZhmmUImyy2
