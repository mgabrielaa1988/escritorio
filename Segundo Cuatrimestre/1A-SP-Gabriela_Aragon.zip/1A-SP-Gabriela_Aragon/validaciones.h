#ifndef VALIDACIONES_H_INCLUDED
#define VALIDACIONES_H_INCLUDED

int esAlfaNumerico(char*);
int validarTamStr(char*,int);
int getInt(char*);
int esNumerico(char*);
float getFloat(char*);
int esNumericoFlotante(char*);
void getString(char*,char*);
char validarGuardar(char);

#endif // VALIDACIONES_H_INCLUDED

