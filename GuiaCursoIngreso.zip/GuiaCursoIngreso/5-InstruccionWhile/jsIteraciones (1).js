function Mostrar()
{
	var contador = 1;

	while (contador <= 10)
	{
		alert (contador);
		contador = contador + 1;
	}

}//FIN DE LA FUNCIÓN