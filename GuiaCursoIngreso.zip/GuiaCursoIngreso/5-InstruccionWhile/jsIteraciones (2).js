function Mostrar()
{
	var contador = 10;

	while (contador >= 1)
	{
		alert (contador);
		contador = contador - 1;
	}
	
}//FIN DE LA FUNCIÓN