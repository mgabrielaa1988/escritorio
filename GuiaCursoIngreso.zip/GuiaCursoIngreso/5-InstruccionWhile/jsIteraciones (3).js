function Mostrar()
{

var clave;

clave = prompt ("Ingrese la clave");
clave = "A";

while (clave != "utn750")
    {
        alert ("Ingrese nuevamente la clave");
        clave = prompt ("Ingrese la clave");
    }


}//FIN DE LA FUNCIÓN
