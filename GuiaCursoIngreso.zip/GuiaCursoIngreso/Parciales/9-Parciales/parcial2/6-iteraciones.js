//Debemos lograr mostrar un mensaje al presionar el botón  'MOSTRAR'.
function Mostrar()
{
	var mejorDiaDeVenta;
	var peorDiaDeVenta;

	var ventasLunes = prompt ("Ingrese el importe de ventas");
	while (ventasLunes <= 0)
		{
			ventasLunes = prompt ("Ingrese un importe valido");
		}

	var ventasMartes = prompt ("Ingrese el importe de ventas");
	while (ventasMartes <= 0)
		{
			ventasMartes = prompt ("Ingrese un importe valido");
		}

	var ventasMiercoles = prompt ("Ingrese el importe de ventas");
	while (ventasMiercoles <= 0)
		{
			ventasMiercoles = prompt ("Ingrese un importe valido");
		}

	var ventasJueves = prompt ("Ingrese el importe de ventas");
	while (ventasJueves <= 0)
		{
			ventasJueves= prompt ("Ingrese un importe valido");
		}

	var ventasViernes = prompt ("Ingrese el importe de ventas");
	while (ventasViernes <= 0)
		{
			ventasViernes = prompt ("Ingrese un importe valido");
		}

	var ventasSabado = prompt ("Ingrese el importe de ventas");
	while (ventasSabado <= 0)
		{
			ventasSabado = prompt ("Ingrese un importe valido");
		}

	var ventasDomingo = prompt ("Ingrese el importe de ventas");
	while (ventasDomingo <= 0)
		{
			ventasDomingo = prompt ("Ingrese un importe valido");
		}

	if (peorDiaDeVenta = true)
		{
			
		}
}

