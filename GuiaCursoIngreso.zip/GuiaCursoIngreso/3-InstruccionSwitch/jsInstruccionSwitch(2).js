function Mostrar()
{
//tomo la edad  
var mesDelAño = document.getElementById('mes').value;

switch (mesDelAño)
{
    case "Enero":
    {
        alert ("Falta para el invierno");
        break;
    }
    case "Febrero":
    {
        alert ("Falta para el invierno");
        break;
    }
    case "Marzo":
    {
        alert ("Falta para el invierno");
        break;
    }
    case "Abril":
    {
        alert ("Falta para el invierno");
        break;
    }
    case "Mayo":
    {
        alert ("Falta para el invierno");
        break;
    }
    case "Junio":
    {
        alert ("Falta para el invierno");
        break;
    }
    case "Julio":
    {
        alert ("Abrigate que hace frio.");
        break;
    }
    case "Agosto":
    {
        alert ("Abrigate que hace frio.");
        break;
    }
    case "Septiembre":
    {
        alert ("Ya pasamos el frio, ahora calor!!!");
        break;
    }
    case "Octubre":
    {
        alert ("Ya pasamos el frio, ahora calor!!!");
        break;
    }
    case "Noviembre":
    {
        alert ("Ya pasamos el frio, ahora calor!!!");
        break;
    }
    case "Diciembre":
    {
        alert ("Ya pasamos el frio, ahora calor!!!");
        break;
    }
}




}//FIN DE LA FUNCIÓN