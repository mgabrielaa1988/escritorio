function Mostrar()
{
//tomo la edad  
var laHora = document.getElementById('hora').value;

switch (laHora)
{
    case "7":
    {
        alert ("Es de mañana");
        break;
    }
    case "8":
    {
        alert ("Es de mañana");
        break;
    }
    case "9":
    {
        alert ("Es de mañana");
        break;
    }
    case "10":
    {
        alert ("Es de mañana");
        break;
    }
    case "11":
    {
        alert ("Es de mañana");
        break;
    }
}
	
	



}//FIN DE LA FUNCIÓN