function Mostrar()
{
//tomo la edad  
var laHora = document.getElementById('hora').value;

if  (laHora >= 0 && laHora <= 24)
{
    switch (laHora)
    {
        case "7":
        {
            alert ("Es de mañana");
            break;
        }
        case "8":
        {
            alert ("Es de mañana");
            break;
        }
        case "9":
        {
            alert ("Es de mañana");
            break;
        }
        case "10":
        {
            alert ("Es de mañana");
            break;
        }
        case "11":
        {
            alert ("Es de mañana");
            break;
        }
        case "12":
        {
            alert ("Es de tarde");
            break;
        }
        case "13":
        {
            alert ("Es de tarde");
            break;
        }
        case "14":
        {
            alert ("Es de tarde");
            break;
        }
        case "15":
        {
            alert ("Es de tarde");
            break;
        }
        case "16":
        {
            alert ("Es de tarde");
            break;
        }
        case "17":
        {
            alert ("Es de tarde");
            break;
        }
        case "18":
        {
            alert ("Es de tarde");
            break;
        }
        case "19":
        {
            alert ("Es de tarde");
            break;
        }
        case "20":
        {
            alert ("Es de noche");
            break;
        }
        case "21":
        {
            alert ("Es de noche");
            break;
        }
        case "22":
        {
            alert ("Es de noche");
            break;
        }
        case "23":
        {
            alert ("Es de noche");
            break;
        }
        case "24":
        {
            alert ("Es de noche");
            break;
        }
        case "0":
        {
            alert ("Es de noche");
            break;
        }
        case "1":
        {
            alert ("Es de noche");
            break;
        }
        case "2":
        {
            alert ("Es de noche");
            break;
        }
        case "3":
        {
            alert ("Es de noche");
            break;
        }
        case "4":
        {
            alert ("Es de noche");
            break;
        }
        case "5":
        {
            alert ("Es de noche");
            break;
        }
        case "6":
        {
            alert ("Es de noche");
            break;
        }
    }
}
else
{
    alert ("La hora no existe.");
}

}//FIN DE LA FUNCIÓN