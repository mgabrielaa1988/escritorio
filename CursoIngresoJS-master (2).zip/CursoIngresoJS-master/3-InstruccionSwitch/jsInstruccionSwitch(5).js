function mostrar() {

    var laHora = document.getElementById("hora").value;
    if (laHora >= 7 && laHora <= 11) {
        alert("Es de mañana.");
    }


}//FIN DE LA FUNCIÓN