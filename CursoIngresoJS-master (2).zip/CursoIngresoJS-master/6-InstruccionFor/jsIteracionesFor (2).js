function mostrar() {
    for (var i = 10; i <= 1; i--) {
        alert(i);
    }
}