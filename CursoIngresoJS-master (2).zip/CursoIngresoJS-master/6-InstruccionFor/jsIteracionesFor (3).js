function mostrar() {

    var repeticiones = prompt("ingrese el número de repeticiones");
    repeticiones = parseInt(repeticiones);

    for (var index = 0; index < repeticiones; index++) {
        alert("Hola UTN FRA");
    }

}//FIN DE LA FUNCIÓN