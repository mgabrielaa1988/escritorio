function mostrar() {
    for (var index = 1; index <= 10; index++) {
        alert(index);
    }
}