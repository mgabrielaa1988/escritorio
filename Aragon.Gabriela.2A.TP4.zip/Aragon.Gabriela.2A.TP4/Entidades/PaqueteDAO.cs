﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Entidades
{
    public static class PaqueteDAO
    {
        private static SqlCommand _comando;
        private static SqlConnection _conexion;

        /// <summary>
        /// Constructor por defecto encargado de configurar la conexión con el servidor de base de datos
        /// </summary>
        static PaqueteDAO()
        {
            PaqueteDAO._conexion = new SqlConnection(Entidades.Properties.Settings.Default.Conexion);
        }

        /// <summary>
        /// Ejecuta un comando INSERT de los datos del paquete a una base de datos.
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        public static bool Insertar(Paquete p)
        {
            bool retorno = false;
            try
            {
                PaqueteDAO._conexion.Open();
                PaqueteDAO._comando = new SqlCommand("INSERT into [correo-sp-2017].[dbo].[Paquetes]([direccionEntrega],[trackingID],[alumno]) VALUES ('" + p.DireccionEntrega + "','" + p.TrackingID + "','Aragon M.Gabriela')", PaqueteDAO._conexion);
                int filasAfectadas = PaqueteDAO._comando.ExecuteNonQuery();
                if (filasAfectadas > 0)
                {
                    retorno = true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                PaqueteDAO._conexion.Close();
            }
            return retorno;
        }
    }
}
